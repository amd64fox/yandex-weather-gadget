var WeatherHttp = (function () {
    function get(url, timeouts, headers, complete) {
        var request = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
        request.SetTimeouts(timeouts[0], timeouts[1], timeouts[2], timeouts[3]);
        request.Open("GET", url, true);
        for (var name in headers) {
            if (Object.prototype.hasOwnProperty.call(headers, name)) {
                request.SetRequestHeader(name, headers[name]);
            }
        }
        request.Send();
        var timer = setInterval(function () {
            if (timer === null) { return; }
            var error = null;
            var response = "";
            try {
                if (!request.WaitForResponse(0)) { return; }
                if (request.Status !== 200) { throw new Error("HTTP " + request.Status); }
                response = request.ResponseText;
            } catch (failure) { error = failure; }
            clearInterval(timer);
            timer = null;
            complete(error, response);
        }, 75);
        return { abort: function () {
            if (timer === null) { return; }
            clearInterval(timer);
            timer = null;
            try { request.Abort(); } catch (error) { }
        } };
    }
    return { get: get };
}());
